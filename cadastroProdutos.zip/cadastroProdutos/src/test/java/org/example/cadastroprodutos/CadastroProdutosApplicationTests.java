package org.example.cadastroprodutos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroProdutosApplicationTests {

    @Test
    void contextLoads() {
    }

}
