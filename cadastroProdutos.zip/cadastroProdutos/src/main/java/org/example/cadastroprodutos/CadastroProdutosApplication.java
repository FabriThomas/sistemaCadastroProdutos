package org.example.cadastroprodutos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroProdutosApplication {

    public static void main(String[] args) {
        SpringApplication.run(CadastroProdutosApplication.class, args);
    }

}
